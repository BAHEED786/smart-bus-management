const id = new URLSearchParams(window.location.search).get('id');
const ticket = document.getElementById('ticket');
const message = document.getElementById('ticketMessage');

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char]));
}

async function loadTicket() {
  if (!id) return message.textContent = 'Booking ID is missing.';
  try {
    const response = await fetch(`/api/bookings/${id}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Booking not found.');
    const b = data.booking;
    ticket.innerHTML = `<div class="ticket-header"><h1>✅ Booking Confirmed</h1><span>Smart Bus Ticket</span></div>
      <hr>
      <div class="ticket-grid">
        <p><b>Booking ID</b><span>#${b.id}</span></p><p><b>Passenger</b><span>${escapeHtml(b.passenger_name)}</span></p>
        <p><b>Phone</b><span>${escapeHtml(b.phone)}</span></p><p><b>Bus Number</b><span>${escapeHtml(b.bus.bus_number)}</span></p>
        <p><b>Operator</b><span>${escapeHtml(b.bus.operator)}</span></p><p><b>Route</b><span>${escapeHtml(b.bus.source)} → ${escapeHtml(b.bus.destination)}</span></p>
        <p><b>Travel Date</b><span>${escapeHtml(b.travel_date)}</span></p><p><b>Seat Number</b><span class="seat-number">${b.seat_no}</span></p>
        <p><b>Departure</b><span>${escapeHtml(b.bus.departure)}</span></p><p><b>Arrival</b><span>${escapeHtml(b.bus.arrival)}</span></p>
        <p><b>Fare</b><span>₹${b.bus.fare}</span></p>
      </div>`;
  } catch (error) { message.textContent = error.message; message.className = 'message error'; }
}
loadTicket();
