const dateInput = document.getElementById('travelDate');
dateInput.value = new Date().toISOString().slice(0, 10);

const form = document.getElementById('searchForm');
const busList = document.getElementById('busList');
const resultCount = document.getElementById('resultCount');
const message = document.getElementById('message');

function showMessage(text, type = 'error') {
  message.textContent = text;
  message.className = `message ${type}`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char]));
}

async function loadBuses() {
  const params = new URLSearchParams({
    source: document.getElementById('source').value.trim(),
    destination: document.getElementById('destination').value.trim(),
    date: dateInput.value
  });

  try {
    const response = await fetch(`/api/buses?${params}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Could not load buses.');

    resultCount.textContent = `${data.buses.length} bus${data.buses.length === 1 ? '' : 'es'}`;
    if (!data.buses.length) {
      busList.innerHTML = '<div class="card empty">No buses found for this route.</div>';
      return;
    }

    busList.innerHTML = data.buses.map((bus) => `
      <article class="card bus-card">
        <div class="bus-title"><h3>${escapeHtml(bus.bus_number)}</h3><span>${escapeHtml(bus.operator)}</span></div>
        <p class="route"><strong>${escapeHtml(bus.source)}</strong> → <strong>${escapeHtml(bus.destination)}</strong></p>
        <p>Departure: <b>${escapeHtml(bus.departure)}</b> · Arrival: <b>${escapeHtml(bus.arrival)}</b></p>
        <p>Fare: <b>₹${bus.fare}</b> · Available seats: <b>${bus.available_seats}</b></p>
        <a class="button" href="/bus/${bus.id}/seats?date=${encodeURIComponent(dateInput.value)}">Select Seats</a>
      </article>
    `).join('');
  } catch (error) {
    showMessage(error.message);
  }
}

form.addEventListener('submit', (event) => { event.preventDefault(); loadBuses(); });
loadBuses();
