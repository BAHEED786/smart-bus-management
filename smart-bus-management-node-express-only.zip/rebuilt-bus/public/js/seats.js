const params = new URLSearchParams(window.location.search);
const busId = window.location.pathname.split('/')[2];
const dateFromUrl = params.get('date') || new Date().toISOString().slice(0, 10);
let selectedSeat = null;
let currentBus = null;

const busInfo = document.getElementById('busInfo');
const seatLayout = document.getElementById('seatLayout');
const bookingForm = document.getElementById('bookingForm');
const bookingDate = document.getElementById('bookingDate');
const selectedSeatText = document.getElementById('selectedSeat');
const message = document.getElementById('message');
bookingDate.value = dateFromUrl;

function showMessage(text, type = 'error') {
  message.textContent = text;
  message.className = `message ${type}`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char]));
}

async function loadSeats() {
  try {
    const response = await fetch(`/api/buses/${busId}?date=${encodeURIComponent(bookingDate.value)}`);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Bus not found.');
    currentBus = data.bus;
    selectedSeat = null;
    selectedSeatText.textContent = 'None';

    busInfo.innerHTML = `<h2>${escapeHtml(data.bus.bus_number)} · ${escapeHtml(data.bus.source)} → ${escapeHtml(data.bus.destination)}</h2>
      <p>Operator: <b>${escapeHtml(data.bus.operator)}</b> · Fare: <b>₹${data.bus.fare}</b></p>
      <p>Departure: <b>${escapeHtml(data.bus.departure)}</b> · Arrival: <b>${escapeHtml(data.bus.arrival)}</b></p>
      <p>Travel date: <b>${escapeHtml(data.date)}</b></p>`;

    seatLayout.innerHTML = Array.from({ length: currentBus.total_seats }, (_, index) => {
      const seat = index + 1;
      const booked = data.bookedSeats.includes(seat);
      return `<button type="button" class="seat ${booked ? 'booked' : ''}" data-seat="${seat}" ${booked ? 'disabled' : ''}>${seat}</button>`;
    }).join('');

    seatLayout.querySelectorAll('.seat:not(.booked)').forEach((button) => {
      button.addEventListener('click', () => {
        seatLayout.querySelectorAll('.seat.selected').forEach((item) => item.classList.remove('selected'));
        button.classList.add('selected');
        selectedSeat = Number(button.dataset.seat);
        selectedSeatText.textContent = selectedSeat;
      });
    });
  } catch (error) {
    showMessage(error.message);
  }
}

bookingDate.addEventListener('change', loadSeats);

bookingForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!selectedSeat) return showMessage('Please select an available seat.');

  const payload = {
    bus_id: currentBus.id,
    passenger_name: document.getElementById('passengerName').value.trim(),
    phone: document.getElementById('phone').value.trim(),
    travel_date: bookingDate.value,
    seat_no: selectedSeat
  };

  try {
    const response = await fetch('/api/bookings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Booking failed.');
    window.location.href = `/ticket?id=${data.booking.id}`;
  } catch (error) {
    showMessage(error.message);
    loadSeats();
  }
});

loadSeats();
