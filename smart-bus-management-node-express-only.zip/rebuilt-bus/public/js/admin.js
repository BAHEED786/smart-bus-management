const message = document.getElementById('message');
const busForm = document.getElementById('busForm');
const bookingRows = document.getElementById('bookingRows');
const busRows = document.getElementById('busRows');
const stats = document.getElementById('stats');

function showMessage(text, type = 'success') { message.textContent = text; message.className = `message ${type}`; }
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char])); }

async function loadAdmin() {
  try {
    const [busResponse, bookingResponse, statsResponse] = await Promise.all([
      fetch('/api/buses'), fetch('/api/admin/bookings'), fetch('/api/admin/stats')
    ]);
    const buses = (await busResponse.json()).buses;
    const bookings = (await bookingResponse.json()).bookings;
    const statData = await statsResponse.json();

    stats.innerHTML = `<div class="stat card"><b>${statData.totalBuses}</b><span>Buses</span></div><div class="stat card"><b>${statData.totalBookings}</b><span>Bookings</span></div><div class="stat card"><b>${statData.totalSeats}</b><span>Total Seats</span></div><div class="stat card"><b>₹${statData.revenue}</b><span>Revenue</span></div>`;

    bookingRows.innerHTML = bookings.length ? bookings.map((b) => `<tr><td>${b.id}</td><td>${escapeHtml(b.passenger_name)}</td><td>${escapeHtml(b.phone)}</td><td>${escapeHtml(b.bus.bus_number)}</td><td>${escapeHtml(b.bus.source)} → ${escapeHtml(b.bus.destination)}</td><td>${escapeHtml(b.travel_date)}</td><td>${b.seat_no}</td><td><button class="danger" onclick="cancelBooking(${b.id})">Cancel</button></td></tr>`).join('') : '<tr><td colspan="8" class="empty">No bookings yet.</td></tr>';
    busRows.innerHTML = buses.map((b) => `<tr><td>${escapeHtml(b.bus_number)}</td><td>${escapeHtml(b.operator)}</td><td>${escapeHtml(b.source)} → ${escapeHtml(b.destination)}</td><td>${escapeHtml(b.departure)}</td><td>₹${b.fare}</td><td>${b.total_seats}</td></tr>`).join('');
  } catch (error) { showMessage(error.message, 'error'); }
}

busForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const payload = Object.fromEntries(new FormData(busForm).entries());
  try {
    const response = await fetch('/api/admin/buses', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Could not add bus.');
    busForm.reset(); busForm.total_seats.value = 40;
    showMessage('Bus added successfully.'); loadAdmin();
  } catch (error) { showMessage(error.message, 'error'); }
});

async function cancelBooking(id) {
  if (!confirm(`Cancel booking #${id}?`)) return;
  try {
    const response = await fetch(`/api/admin/bookings/${id}`, { method: 'DELETE' });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Could not cancel booking.');
    showMessage('Booking cancelled successfully.'); loadAdmin();
  } catch (error) { showMessage(error.message, 'error'); }
}

document.getElementById('refreshBtn').addEventListener('click', loadAdmin);
loadAdmin();
