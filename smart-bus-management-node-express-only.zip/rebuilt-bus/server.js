const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'database.json');
const PUBLIC_DIR = path.join(__dirname, 'public');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(PUBLIC_DIR));

const sampleBuses = [
  { id: 1, bus_number: 'SB101', operator: 'SmartBus', source: 'Hyderabad', destination: 'Vijayawada', departure: '06:30', arrival: '10:30', fare: 450, total_seats: 40 },
  { id: 2, bus_number: 'SB102', operator: 'SmartBus', source: 'Hyderabad', destination: 'Visakhapatnam', departure: '20:00', arrival: '06:00', fare: 850, total_seats: 40 },
  { id: 3, bus_number: 'SB103', operator: 'CityConnect', source: 'Vijayawada', destination: 'Hyderabad', departure: '07:00', arrival: '11:00', fare: 450, total_seats: 40 },
  { id: 4, bus_number: 'SB104', operator: 'CityExpress', source: 'Hyderabad', destination: 'Warangal', departure: '08:00', arrival: '11:00', fare: 300, total_seats: 40 },
  { id: 5, bus_number: 'SB105', operator: 'CityExpress', source: 'Hyderabad', destination: 'Tirupati', departure: '21:00', arrival: '06:00', fare: 750, total_seats: 40 },
  { id: 6, bus_number: 'SB106', operator: 'GreenLine', source: 'Vijayawada', destination: 'Visakhapatnam', departure: '09:00', arrival: '14:00', fare: 500, total_seats: 40 },
  { id: 7, bus_number: 'SB107', operator: 'GreenLine', source: 'Visakhapatnam', destination: 'Hyderabad', departure: '19:30', arrival: '06:30', fare: 900, total_seats: 40 },
  { id: 8, bus_number: 'SB108', operator: 'MetroBus', source: 'Hyderabad', destination: 'Bengaluru', departure: '20:30', arrival: '07:00', fare: 1000, total_seats: 40 },
  { id: 9, bus_number: 'SB109', operator: 'MetroBus', source: 'Bengaluru', destination: 'Hyderabad', departure: '21:00', arrival: '07:30', fare: 1000, total_seats: 40 },
  { id: 10, bus_number: 'SB110', operator: 'TravelStar', source: 'Hyderabad', destination: 'Chennai', departure: '18:00', arrival: '07:00', fare: 1100, total_seats: 40 },
  { id: 11, bus_number: 'SB111', operator: 'TravelStar', source: 'Chennai', destination: 'Hyderabad', departure: '19:00', arrival: '08:00', fare: 1100, total_seats: 40 },
  { id: 12, bus_number: 'SB112', operator: 'SuperFast', source: 'Hyderabad', destination: 'Pune', departure: '17:30', arrival: '08:00', fare: 1300, total_seats: 40 },
  { id: 13, bus_number: 'SB113', operator: 'SuperFast', source: 'Pune', destination: 'Hyderabad', departure: '18:30', arrival: '09:00', fare: 1300, total_seats: 40 },
  { id: 14, bus_number: 'SB114', operator: 'ExpressLine', source: 'Hyderabad', destination: 'Mumbai', departure: '16:00', arrival: '10:00', fare: 1500, total_seats: 40 },
  { id: 15, bus_number: 'SB115', operator: 'ExpressLine', source: 'Mumbai', destination: 'Hyderabad', departure: '17:00', arrival: '11:00', fare: 1500, total_seats: 40 }
];

function ensureDatabase() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    writeDatabase({ nextBusId: 16, nextBookingId: 1, buses: sampleBuses, bookings: [] });
  }
}

function readDatabase() {
  ensureDatabase();
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

function writeDatabase(database) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(database, null, 2));
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function findBus(database, id) {
  return database.buses.find((bus) => bus.id === Number(id));
}

function getBookedSeats(database, busId, travelDate) {
  return database.bookings
    .filter((booking) => booking.bus_id === Number(busId) && booking.travel_date === travelDate)
    .map((booking) => booking.seat_no)
    .sort((a, b) => a - b);
}

function bookingWithBus(database, booking) {
  const bus = findBus(database, booking.bus_id);
  return bus ? { ...booking, bus } : booking;
}

// Home page
app.get('/', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// Seat page
app.get('/bus/:id/seats', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'seats.html'));
});

// Ticket page
app.get('/ticket', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'ticket.html'));
});

// Admin page
app.get('/admin', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'admin.html'));
});

// GET all buses with optional route filtering
app.get('/api/buses', (req, res) => {
  const database = readDatabase();
  const source = String(req.query.source || '').trim().toLowerCase();
  const destination = String(req.query.destination || '').trim().toLowerCase();
  const date = req.query.date || today();

  const buses = database.buses
    .filter((bus) => !source || bus.source.toLowerCase().includes(source))
    .filter((bus) => !destination || bus.destination.toLowerCase().includes(destination))
    .map((bus) => {
      const bookedSeats = getBookedSeats(database, bus.id, date);
      return { ...bus, available_seats: bus.total_seats - bookedSeats.length };
    });

  res.json({ date, buses });
});

// GET one bus and its seat availability
app.get('/api/buses/:id', (req, res) => {
  const database = readDatabase();
  const bus = findBus(database, req.params.id);

  if (!bus) return res.status(404).json({ error: 'Bus not found.' });

  const date = req.query.date || today();
  const bookedSeats = getBookedSeats(database, bus.id, date);

  res.json({ bus, date, bookedSeats });
});

// Create booking
app.post('/api/bookings', (req, res) => {
  const { bus_id, passenger_name, phone, travel_date, seat_no } = req.body;
  const database = readDatabase();
  const bus = findBus(database, bus_id);
  const seat = Number(seat_no);

  if (!bus || !passenger_name || !phone || !travel_date || !seat_no) {
    return res.status(400).json({ error: 'All booking fields are required.' });
  }

  if (!/^\d{10}$/.test(String(phone))) {
    return res.status(400).json({ error: 'Phone number must contain exactly 10 digits.' });
  }

  if (!Number.isInteger(seat) || seat < 1 || seat > bus.total_seats) {
    return res.status(400).json({ error: 'Invalid seat number.' });
  }

  const alreadyBooked = database.bookings.some(
    (booking) => booking.bus_id === bus.id && booking.travel_date === travel_date && booking.seat_no === seat
  );

  if (alreadyBooked) {
    return res.status(409).json({ error: 'Sorry! This seat is already booked.' });
  }

  const booking = {
    id: database.nextBookingId++,
    bus_id: bus.id,
    passenger_name: String(passenger_name).trim(),
    phone: String(phone).trim(),
    travel_date,
    seat_no: seat,
    booked_at: new Date().toISOString()
  };

  database.bookings.push(booking);
  writeDatabase(database);

  res.status(201).json({ booking: bookingWithBus(database, booking) });
});

// Get a single booking
app.get('/api/bookings/:id', (req, res) => {
  const database = readDatabase();
  const booking = database.bookings.find((item) => item.id === Number(req.params.id));

  if (!booking) return res.status(404).json({ error: 'Booking not found.' });
  res.json({ booking: bookingWithBus(database, booking) });
});

// Admin: all bookings
app.get('/api/admin/bookings', (req, res) => {
  const database = readDatabase();
  const bookings = [...database.bookings]
    .sort((a, b) => b.id - a.id)
    .map((booking) => bookingWithBus(database, booking));

  res.json({ bookings });
});

// Admin: add bus
app.post('/api/admin/buses', (req, res) => {
  const { bus_number, operator, source, destination, departure, arrival, fare, total_seats } = req.body;
  const database = readDatabase();
  const seats = Number(total_seats);
  const busFare = Number(fare);

  if (!bus_number || !operator || !source || !destination || !departure || !arrival || !fare || !total_seats) {
    return res.status(400).json({ error: 'All bus fields are required.' });
  }

  if (!Number.isInteger(seats) || seats < 1 || seats > 100 || Number.isNaN(busFare) || busFare < 0) {
    return res.status(400).json({ error: 'Enter valid fare and seat values.' });
  }

  const duplicate = database.buses.some(
    (bus) => bus.bus_number.toLowerCase() === String(bus_number).trim().toLowerCase()
  );

  if (duplicate) return res.status(409).json({ error: 'Bus number already exists.' });

  const bus = {
    id: database.nextBusId++,
    bus_number: String(bus_number).trim(),
    operator: String(operator).trim(),
    source: String(source).trim(),
    destination: String(destination).trim(),
    departure,
    arrival,
    fare: busFare,
    total_seats: seats
  };

  database.buses.push(bus);
  writeDatabase(database);
  res.status(201).json({ bus });
});

// Admin: cancel/delete booking
app.delete('/api/admin/bookings/:id', (req, res) => {
  const database = readDatabase();
  const index = database.bookings.findIndex((booking) => booking.id === Number(req.params.id));

  if (index === -1) return res.status(404).json({ error: 'Booking not found.' });

  const [removed] = database.bookings.splice(index, 1);
  writeDatabase(database);
  res.json({ message: 'Booking cancelled successfully.', booking: removed });
});

// Admin: dashboard statistics
app.get('/api/admin/stats', (req, res) => {
  const database = readDatabase();
  const revenue = database.bookings.reduce((sum, booking) => {
    const bus = findBus(database, booking.bus_id);
    return sum + (bus ? Number(bus.fare) : 0);
  }, 0);

  res.json({
    totalBuses: database.buses.length,
    totalBookings: database.bookings.length,
    totalSeats: database.buses.reduce((sum, bus) => sum + bus.total_seats, 0),
    revenue
  });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Route not found.' });
});

ensureDatabase();

app.listen(PORT, () => {
  console.log(`Smart Bus System running at http://localhost:${PORT}`);
  console.log('Backend: Node.js + Express.js');
  console.log('Storage: Node.js file system (data/database.json)');
});
