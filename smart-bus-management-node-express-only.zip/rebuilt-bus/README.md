# Smart Bus Management & Seat Reservation System

A complete bus search and seat reservation web application built using **Node.js + Express.js only**.

## Technology
- Node.js
- Express.js
- HTML5
- CSS3
- Vanilla JavaScript
- Node.js built-in `fs` and `path` modules

There is **no React, EJS, SQLite, MongoDB, MySQL, Bootstrap, or Nodemon dependency** in this version.

## Features
- Search buses by source and destination
- Select travel date
- Live seat availability from stored bookings
- Interactive seat selection
- Passenger booking
- Duplicate-seat protection
- Booking confirmation ticket
- Print ticket
- Admin dashboard
- Add new buses
- View all bookings
- Cancel bookings
- Dashboard statistics and revenue
- Persistent data stored in `data/database.json`

## Run

1. Open a terminal in this project folder.
2. Install the only npm dependency:

```bash
npm install
```

3. Start the server:

```bash
npm start
```

4. Open:

`http://localhost:3000`

Admin:

`http://localhost:3000/admin`

## Important

This version intentionally uses a JSON file instead of a database because the requirement was to use Node.js and Express.js only. For a production deployment with multiple server instances, a proper database should be used.
